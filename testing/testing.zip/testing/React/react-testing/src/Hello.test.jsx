import { render, screen } from "@testing-library/react";
import Hello from "./Hello";

test("renders hello message", () => {
  render(<Hello name="ِAhmed" />);
  const heading = screen.getByText("Hello Ahmed");
  expect(heading).toBeInTheDocument();
});
