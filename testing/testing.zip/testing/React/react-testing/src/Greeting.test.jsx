import { render, screen, fireEvent } from "@testing-library/react";
import Greeting from "./Greeting";

describe("Greeting Component", () => {
  test("renders input and button correctly", () => {
    render(<Greeting />);
    expect(screen.getByTestId("name-input")).toBeInTheDocument();
    expect(screen.getByTestId("greet-btn")).toBeInTheDocument();
  });

  test("shows greeting message after typing name and clicking button", () => {
    render(<Greeting />);

    const input = screen.getByTestId("name-input");
    const button = screen.getByTestId("greet-btn");

    // simulate typing
    fireEvent.change(input, { target: { value: "Ahmed" } });
    expect(input.value).toBe("Ahmed");

    // simulate button click
    fireEvent.click(button);

    // check greeting message
    const message = screen.getByTestId("greet-message");
    expect(message).toHaveTextContent("Hello, Ahmed");
  });

  test("shows warning message when input is empty", () => {
    render(<Greeting />);

    const button = screen.getByTestId("greet-btn");
    fireEvent.click(button);

    const message = screen.getByTestId("greet-message");
    expect(message).toHaveTextContent("Please enter your name");
    expect(message).toHaveStyle("color: #dc2626");
  });
});
