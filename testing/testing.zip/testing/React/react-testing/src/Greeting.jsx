import React, { useState } from "react";

export default function Greeting() {
  const [name, setName] = useState("");
  const [greet, setGreet] = useState("");

  const handleClick = () => {
    const trimmedName = name.trim();
    if (!trimmedName) {
      setGreet("Please enter your name first!");
      return;
    }
    setGreet(`Hello, ${trimmedName}! Welcome aboard`);
  };

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        gap: "1rem",
        padding: "2rem",
        fontFamily: "Inter, Arial, sans-serif",
      }}
    >
      <input
        type="text"
        placeholder="Enter your name"
        value={name}
        onChange={(e) => setName(e.target.value)}
        data-testid="name-input"
        style={{
          padding: "0.5rem 1rem",
          borderRadius: "8px",
          border: "1px solid #ccc",
          width: "220px",
          fontSize: "1rem",
        }}
      />

      <button
        onClick={handleClick}
        data-testid="greet-btn"
        style={{
          backgroundColor: "#2563eb",
          color: "#fff",
          border: "none",
          borderRadius: "8px",
          padding: "0.6rem 1.2rem",
          cursor: "pointer",
          fontSize: "1rem",
          transition: "background-color 0.3s ease",
        }}
        onMouseEnter={(e) => (e.target.style.backgroundColor = "#1d4ed8")}
        onMouseLeave={(e) => (e.target.style.backgroundColor = "#2563eb")}
      >
        Greet
      </button>

      {greet && (
        <h2
          data-testid="greet-message"
          style={{
            marginTop: "1rem",
            color: greet.includes("ُerror") ? "#dc2626" : "#16a34a",
          }}
        >
          {greet}
        </h2>
      )}
    </div>
  );
}
