import React from "react";

export default function Hello({ name }) {
  return <h1>Hello {name}</h1>;
}
